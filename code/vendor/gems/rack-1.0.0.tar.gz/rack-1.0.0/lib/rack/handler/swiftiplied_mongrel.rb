require 'swiftcore/swiftiplied_mongrel'

module Rack
  module Handler
    class SwiftipliedMongrel < Handler::Mongrel
    end
  end
end
